<?php

if(isset($_POST["userData"]))
{
	$connect = mysqli_connect('localhost','root','','testing');
	$qry = "SELECT * FROM `testing`";
	$run = mysqli_query($connect, $qry);
	if(mysqli_num_rows($run)>0)
	{
		echo '<table class="table table-striped"><tr><th>Name</th><th>Mobile</th><th>Email</th><th>Action</th><th></th></tr>';
		while($result = mysqli_fetch_array($run))
		{
			echo '<tr>
					<td>'.$result["name"].'</td>
					<td>'.$result["mobile"].'</td>
					<td>'.$result["email"].'</td>
					<td><p class="delete" id='.$result["id"].'><i class="fa fa-trash" style="font-size:24px;color:red;"></i></p></td>
					<td><p class="edit" id='.$result["id"].'><i class="fa fa-edit" style="font-size:24px;"></i></p></td>			
					
					
			</tr>';
		}

		echo '</table>';
	}
}

if(isset($_POST["name"]))
{
	if($_POST["submit"] =="submit")
	{
		$name = $_POST["name"];
		$mobile = $_POST["mobile"];
		$email = $_POST["email"];
		$connect = mysqli_connect('localhost','root','','testing');
		$qry = "INSERT INTO `testing`(`name`,`mobile`,`email`) VALUES ('$name', '$mobile', '$email')";
		$run = mysqli_query($connect, $qry);

		if(!empty($run))
		{
			echo "Data has submitted!";
		}
	}
	if($_POST["submit"] == "update")
	{
		$uid = $_POST["uid"];
		$name = $_POST["name"];
		$mobile = $_POST["mobile"];
		$email = $_POST["email"];
		$con = mysqli_connect('localhost','root','','testing');
		$qry = "UPDATE `testing` SET `name`= '$name',`mobile`= '$mobile',`email`='$email' WHERE `id` = '$uid'";
		$run = mysqli_query($con, $qry);
		if(!empty($run))
		{
			echo "Your data has updated successfully";
		}
	}
	
}

if(isset($_POST["id"]))
{
	$id = $_POST["id"];
	$connect = mysqli_connect('localhost','root', '','testing');
	$qry = "DELETE FROM `testing` WHERE `id`= '$id'";
	$run = mysqli_query($connect, $qry);
	if(!empty($run))
	{
		echo "Data has deleted successfully!";
	}

}



if(isset($_POST["uId"]))
{
	$id = $_POST["uId"];
	$data = array();
	$con = mysqli_connect('localhost','root','','testing');
	$qry = "SELECT * FROM `testing` WHERE `id`='$id'";
	$run = mysqli_query($con, $qry);
	if(!empty($run))
	{
		$result = mysqli_fetch_array($run);
		$data["name"] = $result["name"];
		$data["mobile"] = $result["mobile"];
		$data["email"] = $result["email"];
		echo json_encode($data);

	}
}










?>