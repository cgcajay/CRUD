<!DOCTYPE html>
<html>
<head>
	<title>How to fetch Data from database using Ajax, Jquery and PHP</title>
	<script type="text/javascript" src="assets/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="assets/bootstrap/dist/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/dist/css/bootstrap.min.css">
</head>
<body>
	<div id="login"></div>
	<div class="container">
		<div class="row">
			<div class="col-sm-2"></div>
			<div class="col-sm-8">
				<div style="color: blue;">Welcome&nbsp;&nbsp;&nbsp;</div>
				<div id="success"></div>
				<div class="form-group">
					<label>Enter Name:</label>
					<input type="text" name="name" id="name" class="form-control">
				</div>

				<div class="form-group">
					<label>Enter Mobile No:</label>
					<input type="text" name="mobile" id="mobile" class="form-control">
				</div>

				<div class="form-group">
					<label>Enter Email id:</label>
					<input type="text" name="email" id="email" class="form-control">
					<input type="hidden" name="id" id="sid">
				</div>

				<button type="button" id="submit" value="submit" style="background-color: burlywood;" class="form-control">Submit</button>
			</div>
			<div class="col-sm-2"></div>
		</div>
		<br/>
		<div class="row">
			<div class="col-sm-2"></div>
			<div class="col-sm-8">
				<div id="userData">
				
			</div>
			</div>
			<div class="col-sm-2"></div>
			
		</div>
	</div>
	<script type="text/javascript">
		$(document).ready(function(){
 			$(document).bind("contextmenu",function(e){
   			return false;
 		});
	});
		$(document).ready(function(){

			
			getData();

			function getData(){
				var userData = "data";
				$.ajax({
					url : "getData.php",
					method : "post",
					data : {userData: userData},
					success : function(data){
						$('#userData').html(data);
					}
				});
			}

			$('#submit').click(function(){
				var submit = $(this).val();
				var uid = $('#sid').val();
				var name = $('#name').val();
				var mobile = $('#mobile').val();
				var email = $('#email').val();
				if(name !='' && mobile !='')
				{
					$.ajax({
						url : "getData.php",
						method : "post",
						data : {submit:submit, uid: uid, name: name, mobile: mobile, email:email},
						success : function(data){
							$('#name').val("");
							$('#mobile').val("");
							$('#email').val("");
							$('#success').addClass("alert alert-success");
							$('#success').text(data);
							if($('#userData').hide())
							{
								$('#submit').val("submit");
								$('#submit').text("Submit");
								$('#userData').show();
							}
							getData();
						}
					});
				}
				else
				{
					if(name =='')
					{
						alert("Enter Name");
						
					}

					return false;
					if(mobile =='')
					{
						alert("Enter mobile");
					}
				}

			});


			$(document).on('click', '.delete', function(){
				 var id = $(this).attr("id");
				 if(confirm("Are you sure delete this record, If ok then click 'OK'"))
				 {
				 	$.ajax({
				 	url: "getData.php",
				 	method: "post",
				 	data: {id:id},
				 	success: function(data){
				 		$('#success').addClass("alert alert-success");
				 		$('#success').text(data);
				 		getData();s
				 	}
				 });
				 }
				 else
				 {
				 	return false;
				 }
				 
			});


			$(document).on('click', '.edit', function(){
				var uId = $(this).attr("id");
				$.ajax({
					url: "getData.php",
					method: "post",
					data: {uId:uId},
					dataType: "json",
					success: function(data){
						$('#name').val(data.name);
						$('#mobile').val(data.mobile);
						$('#email').val(data.email);
						$('#sid').val(uId);
						$('#submit').val("update");
						$('#submit').text("Update");
						$('#userData').hide();
					}
				});
			});



		});
	</script>
</body>
</html>

